
GenericApp README.TXT file.
===========================

VERSION HISTORY.
================

---------------- Version 1.0.0 (M/D/YYYY) -----------------------------------------------
    First version compiled with Microsoft Visual Basic 5.0.

