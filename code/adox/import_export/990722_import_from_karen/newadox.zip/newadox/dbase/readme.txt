
AdOx README.TXT file.
======================================================

VERSION HISTORY.
================

---------------- Version 01.00.01 (??) -------------------------------------
(18-Dec-1998)


---------------- Version 01.00.02 (17-May-1999) -------------------------------------
(17-May-1999)
- Compiled application in VB 6.0.  No problems.

---------------- Version 01.00.03 (17-May-1999) -------------------------------------
(??-July-1999)
- A complete rewrite of the program was performed using the Generic App template.
- Previously the main window and photochemical window had fixed units.  Now, these units 
	can be reset by the user during data entry.
-


