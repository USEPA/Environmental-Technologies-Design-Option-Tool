
DyeStudy Application README.TXT file.
=====================================

VERSION HISTORY.
================

---------------- Version 1.0.1 (09/16/1999) -----------------------------------------------
- Created a stand-alone dye study application using the GenericApp as a model.


