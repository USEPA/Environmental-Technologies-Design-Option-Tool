
DyeStudy Application README.TXT file.
=====================================

VERSION HISTORY.
================

---------------- Version 1.0.8 (10/26/1999) -----------------------------------------------
- Created a stand-alone dye study application using the GenericApp as a model.
- Enabled the dye study application to be called from the ADOX application (or other application
	as necessary).
- Displayed a graphic representation of the results of the calculations.


