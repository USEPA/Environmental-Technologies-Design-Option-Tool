5/24/99 Installing Uppmem:

In order to run Uppmem, you will need to place all of the files in
the "DLLs" folder into your "Windows/System" directory.

Uppmem may be modified by anybody for any reason, as long as the
modified versions are made freely available for other researchers.

I hope that you find this program useful.

-- Brian Huff